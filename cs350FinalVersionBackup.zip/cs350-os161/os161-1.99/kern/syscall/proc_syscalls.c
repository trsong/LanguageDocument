#include <types.h>
#include <kern/errno.h>
#include <kern/unistd.h>
#include <kern/wait.h>
#include <lib.h>
#include <syscall.h>
#include <current.h>
#include <proc.h>
#include <thread.h>
#include <addrspace.h>
#include <copyinout.h>

#include "opt-A2.h"

  /* this implementation of sys__exit does not do anything with the exit code */
  /* this needs to be fixed to get exit() and waitpid() working properly */

#if OPT_A2
#include <machine/trapframe.h>
#include <synch.h>
#include <vnode.h>
#include <vm.h>
#include <vfs.h>
#include <kern/fcntl.h>
static void fork_child_thread(void *, unsigned long);
struct semaphore;
#endif


/*
Just has an experiment on POSIX linux,
wc = wait(NULL);
wc = wait(NULL);
first wc return the pid of children process
second wc should return -1
Guess: proc_destroy was called during wait.
*/

void sys__exit(int exitcode) {

  struct addrspace *as;
  struct proc *p = curproc;
  /* for now, just include this to keep the compiler from complaining about
     an unused variable */
  (void)exitcode;



#if OPT_A2
  DEBUG(DB_EXEC, "====SYSCALL====  sys__exit: Enter sys__exit\n");
  DEBUG(DB_EXEC, "====SYSCALL====  sys__exit: exit proc: %s(pid:%d)\n",p->p_name,p->pid);

  KASSERT(proctabl[p->pid] != NULL);

  lock_acquire(p->proc_lock);
#endif

  DEBUG(DB_SYSCALL,"Syscall: _exit(%d)\n",exitcode);

  KASSERT(curproc->p_addrspace != NULL);
  as_deactivate();
  /*
   * clear p_addrspace before calling as_destroy. Otherwise if
   * as_destroy sleeps (which is quite possible) when we
   * come back we'll be calling as_activate on a
   * half-destroyed address space. This tends to be
   * messily fatal.
   */
  as = curproc_setas(NULL);
  as_destroy(as);



#if OPT_A2
  p->exited = true;
  p->exitcode = _MKWAIT_EXIT(exitcode);
  cv_broadcast(p->proc_cv,p->proc_lock);
  lock_release(p->proc_lock);
#endif

  /* detach this thread from its process */
  /* note: curproc cannot be used after this call */
  proc_remthread(curthread);

  /* if this is the last user process in the system, proc_destroy()
     will wake up the kernel menu thread */

  proc_destroy(p); 		

#if OPT_A2

#endif

  thread_exit();
  /* thread_exit() does not return, so we should never get here */
  panic("return from thread_exit in sys_exit\n");
}


/* stub handler for getpid() system call                */
int
sys_getpid(pid_t *retval)
{
  /* for now, this is just a stub that always returns a PID of 1 */
  /* you need to fix this to make it work properly */
#if OPT_A2
  *retval = curproc->pid;
#else
  *retval = 1;
#endif
  return(0);
}


// Jun 13: implement sys_fork
//	   add struct forkdata


#if OPT_A2
struct _forkdata{
	struct semaphore *child_sem;	// child_sem init to 0, parenent cannot pass P(child_sem), until child call V(child_sem)
	struct proc *parent;		// pass down the parent process so that the child is able to attach to it.
	struct trapframe *tf;		// parent's trap frame
	pid_t child_return_pid;		// pass down to child, in order to modify it.
};
#endif 

#if OPT_A2
static
void
fork_child_thread(void *parentData, 
		  unsigned long unused_data)
{
	(void) unused_data;
	int err=0;
	struct trapframe child_tf;	 // this is kernel mode, we are already on kernel stack, so just create trapframe here.	
	struct _forkdata *data = (struct _forkdata *) parentData;
	struct proc *childProc = curthread->t_proc;

	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: Enter\n");
	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: parent(pid:%d) child(pid:%d)\n",data->parent->pid,childProc->pid);
	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: copy parent's AS.\n");

	// copy parent's address space	
	struct addrspace *child_as;
	err = as_copy(data->parent->p_addrspace,&child_as);
	//if(err== ENOMEM) panic(".....No enough memory!!!!!!!!  What the hell is this !\n");

	if(err){
		data->child_return_pid = -1;
		V(data->child_sem);
		
		// err == ENOMEM do happen!
		// Must call proc_remthread, and proc_destroy before call thread_exit()
		// Note: even you call return, os will still call thread_exit() implicitly for you.
		//	 so better call it explicitly
		if(err== ENOMEM) DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: copy AS Failed, return to parent.\n");
	        proc_remthread(curthread);
  		proc_destroy(childProc);
		thread_exit();
	}

	childProc->p_addrspace = child_as;
	curproc_setas(child_as);
	as_activate();

	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: copy AS finished.\n");
	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: copy parent's tf.\n");
	// copy parent's trap frame
	memcpy(&child_tf,data->tf, sizeof(struct trapframe));

	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: copy tf Finished.\n");
	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: copy parent's vfs.\n");

	// copy parent's vfs
	if(data->parent->p_cwd != NULL){
		VOP_INCREF(data->parent->p_cwd);
		childProc->p_cwd = data->parent->p_cwd;
	}
	#ifdef UW
	childProc->console = data->parent->console;
	#endif

	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: copy vfs Finished.\n");

	//in parent's sys_fork, it should return child's PID, and store it in tf_v0
	//in child's thread here, the only difference is that, we return 0, and report no err
	child_tf.tf_v0 = 0;
	child_tf.tf_a3 = 0;
	// Just searhc online, says, need to push child's PC += 4, I don't understand right now
	// Just assuming this is true!
	// I guess this would avoid, the child process keep calling fork.
	// since the current PC address we passed in is where we call fork in user stack.
	child_tf.tf_epc += 4;
	
	data->child_return_pid = curproc->pid;
	
	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork:  fork_child_thread: child Finished. Release the lock for parent.\n");
	// child process is ready
	V(data->child_sem);
	// child proess returns
	mips_usermode(&child_tf);

	panic("mips fail to switch to usermode.");
		
	
}
#endif

#if OPT_A2
int
sys_fork(struct trapframe *tf,
		pid_t *retval)
{
	DEBUG(DB_EXEC, "====SYSCALL===  sys_fork: Enter sys_fork\n");
	struct _forkdata forkdata;
	forkdata.child_sem = sem_create("semaphore for child",0);	//parent cannot pass P, until child pass V
	if(forkdata.child_sem == NULL){
		*retval = -1;	
		return ENOMEM;
	}
	DEBUG(DB_EXEC, "====SYSCALL===  sys_fork: forkdata.parent: %s(pid: %d)\n", curproc->p_name,curproc->pid);

	forkdata.parent = curproc;		// set parent to be current process
	forkdata.tf = tf;			// parent's trap frame
	forkdata.child_return_pid = -1;		// initialize this field to be -1
	
/*
int thread_fork(const char *name, struct proc *proc,
                void (*func)(void *, unsigned long),
                void *data1, unsigned long data2);

*/
	char *childname = kstrdup(curthread->t_name);
	if(childname == NULL){
		sem_destroy(forkdata.child_sem);
		*retval = -1;
		return ENOMEM;
	}

	
	char *childprocname = kstrdup(curproc->p_name);
	if(childprocname == NULL){
		sem_destroy(forkdata.child_sem);
		*retval = -1;
		kfree(childname);
		return ENOMEM;
	}

	// create a new process, used by thread_fork
	struct proc *childProc = proc_create_runprogram(childprocname);
	if(childProc == NULL){
		sem_destroy(forkdata.child_sem);
		*retval = -1;
		kfree(childname);
		kfree(childprocname);
		return ENOMEM;	// no memory
	}

	childProc->parent = curproc;
	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork: ready to fork child thread.\n");

	int err = thread_fork(childname,childProc,&fork_child_thread,(void *) &forkdata,0);
	if(err){
		sem_destroy(forkdata.child_sem);
		*retval = -1;
		return ENOMEM;
	}

	// wait for child to be able to have pid
	P(forkdata.child_sem);
	 DEBUG(DB_EXEC,"====SYSCALL==== sys_fork: child thread release the lock.\n");

	if(forkdata.child_return_pid == -1){
		sem_destroy(forkdata.child_sem);
		*retval = -1;
		DEBUG(DB_EXEC,"====SYSCALL==== sys_fork: Failed on No memory.\n");
		return ENOMEM;	// no memory
	}else if (forkdata.child_return_pid == 0){
		sem_destroy(forkdata.child_sem);
		*retval = -1;
		DEBUG(DB_EXEC,"====SYSCALL==== sys_fork: Failed on too many processes.\n");
		return EMPROC;	// already too many threads than the limit
	}
	
	sem_destroy(forkdata.child_sem);
	*retval = forkdata.child_return_pid;
	kfree(childname);
	kfree(childprocname);
	DEBUG(DB_EXEC,"====SYSCALL==== sys_fork: return value childpid: %d\n",*retval);
	return(0);
}
#endif

/* stub handler for waitpid() system call                */

int
sys_waitpid(pid_t pid,
	    userptr_t status,
	    int options,
	    pid_t *retval)
{
  int exitstatus;
  int result;
#if OPT_A2
  DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: Enter sys_waitpid\n");
  DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: waitpid(%d), curproc:%s(pid:%d)\n",pid,curproc->p_name,curproc->pid);

  struct proc *childProc;
  childProc = NULL;
#endif


  if (options != 0) {
    *retval = -1;
    return(EINVAL);
  }
#if OPT_A2
  if(status == NULL){
    *retval = -1;
    DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: failed on invalid userptr status!\n");
    return EFAULT;
  }

// 11111111.....000
//		011 good alignment
// 1111111......010
//		011 bad alignment
  if( ((unsigned long)status & 3) != 0){
    *retval = -1;
    DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: failed on invalid userptr status!\n");
    return EFAULT;
  }

  if(proctabl[pid] == NULL){
    *retval = -1;
     DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: failed. pid not exist!\n");
    return ESRCH;	
  }
 
   childProc = proctabl[pid];
   if(childProc->parent != curproc){
     *retval = -1;
      DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: failed. Only parent can interest on this pid. \n");
     return ECHILD;	
   }

   lock_acquire(childProc->proc_lock);
   while(!childProc->exited){
	 DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: child not exit yet, busy wating ......\n");
	cv_wait(childProc->proc_cv,childProc->proc_lock);
   }
   DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: now child exit!\n");
   exitstatus = childProc->exitcode;

   DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: parent(pid:%d), child(id:%d) exitcode: %d\n", curproc->pid, childProc->pid, exitstatus);

#else
  /* for now, just pretend the exitstatus is 0 */
  exitstatus = 0;
#endif

  result = copyout((void *)&exitstatus,status,sizeof(int));
  if (result) {
    return(result);
  }
  *retval = pid;

#if OPT_A2
  lock_release(childProc->proc_lock);

  lock_destroy(childProc->proc_lock); // lock, cv should be destroyed in sys_waitpid, if proc is not orphan
  cv_destroy(childProc->proc_cv);
  proctabl[childProc->pid] = NULL;
  kfree(childProc);
  DEBUG(DB_EXEC, "====SYSCALL====  sys_waitpid: free pid and return: %d ", *retval);
#endif
  return(0);
}


#if OPT_A2
// note: each time need to (const char *) program, and (char **) uargs
int
sys_execv(const_userptr_t program,
  	  userptr_t uargs)
{
    (void) program;
    (void) uargs;

    struct addrspace *as, *old_as;
    struct vnode *v;
    vaddr_t entrypoint, stackptr;
    int result;
    char *progname;
    int tmplen;


   	if(program == NULL)
	{
		return EFAULT;
	}

    old_as = NULL;

    

    if(strlen((char *) program) > 1024) return E2BIG;
    progname = kmalloc(sizeof(char)*(strlen((char *) program)+1));
    result = copyinstr(program,progname,1024,(size_t *)&tmplen);
	if (result) {
		return result;
	}

    	/* Open the file. */
	result = vfs_open(progname, O_RDONLY, 0, &v);
	if (result) {
		return result;
	}
    kfree(progname);

	/* Create a new address space. */
	as = as_create();
	if (as ==NULL) {
		vfs_close(v);
		return ENOMEM;
	}
   
// the following code must be done before destroy old as
    int *buffer = (int *) kmalloc((sizeof(int))*15700);
    if(buffer == NULL) return ENOMEM;
    int num;

    
    for(num=0;((char **)uargs)[num]!=NULL;num++){
        buffer[num] = 0;  
    }
     
    DEBUG(DB_EXEC, "====SYSCALL====  sys_execv: num=%d \n", num);
    buffer[num] = 0;
    
    char *c = (char *) &buffer[num+1];
    for(int i=0; i<num; i++){
        const char *target = ((char **)uargs)[i];
        int length = 0;
        buffer[i] = (char *)c - (char *)&buffer[i];
        DEBUG(DB_EXEC, "====SYSCALL====  sys_execv: buffer[%d]:%d (%x)\n",i,buffer[i],(int)(&buffer[i]));
        if(strlen(target) > 1024){
            kfree(buffer);
            return E2BIG;
        }
        result = copyinstr((const_userptr_t) target,(void *)c,1024,(size_t *)&length);
        DEBUG(DB_EXEC, "====SYSCALL====  sys_execv: argv[%d] = %s, len = %d, c = %x\n",i,c,length,(int)c);
        if(result){
            kfree(buffer);
            return result;
        }

        c += length;
        while( ((unsigned long)c & 3) != 0){
            DEBUG(DB_EXEC, "====SYSCALL====  sys_execv:  c(%x): %s\n",(int) c,c);
            *c = '\0';
            c++;
        }
    }

    // destroy old_as, and set new as
	as_deactivate();
    old_as = curproc_setas(as);
    as_activate();
    as_destroy(old_as);

    	/* Load the executable. */
	result = load_elf(v, &entrypoint);
	if (result) {
		/* p_addrspace will go away when curproc is destroyed */
		vfs_close(v);
		return result;
	}

	/* Done with the file now. */
	vfs_close(v);

	/* Define the user stack in the address space */
	result = as_define_stack(as, &stackptr);
	if (result) {
		/* p_addrspace will go away when curproc is destroyed */
		return result;
	}




    // Without argument passing
	/* Warp to user mode. */
	// enter_new_process(0 /*argc*/, NULL /*userspace addr of argv*/,
	//		  stackptr, entrypoint);
	

// Right now I did not do any return value checking or argument check!
// Be careful!

    // With argument passing

    
   size_t buffer_size = (void *)c - (void *)&buffer[0] + 4;
   //KASSERT(((unsigned long)buffer_size & 3) == 0); // size is divisable by 4

    stackptr -= buffer_size;
    while(((unsigned long)stackptr & 7) != 0){
        stackptr--;
    }
    for(int i=0; i<num; i++){
        DEBUG(DB_EXEC,"====SYSCALL==== sys_execv: buffer[%d]=%d\n",i,buffer[i]);
        buffer[i] = stackptr + 4*i + buffer[i];
        DEBUG(DB_EXEC,"====SYSCALL==== sys_execv: stackptr(%x), buffer[%d]=%x\n",(int)stackptr,i,(int)buffer[i]);
    }

    result = copyout((void *)&buffer[0], (void *)stackptr, buffer_size);
    if(result){
        kfree(buffer);
        return result;
    }
    kfree(buffer);

    enter_new_process(num /*argc*/, (userptr_t) stackptr /*userspace addr of argv*/,
			  stackptr, entrypoint);
	/* enter_new_process does not return. */
	panic("enter_new_process returned\n");
	return EINVAL;
       
}
#endif


