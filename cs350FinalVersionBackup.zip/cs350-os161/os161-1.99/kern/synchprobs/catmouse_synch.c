#include <types.h>
#include <lib.h>
#include <synchprobs.h>
#include <synch.h>


static volatile int status;
static int bowlNum;
static struct lock **bowlockArry;
static struct cv *cat_turn_cv;
static struct cv *mouse_turn_cv;

#define is_cat_turn() (status >= 0)
#define is_mouse_turn() (status <= 0)


/* 
 * The CatMouse simulation will call this function once before any cat or
 * mouse tries to each.
 *
 * You can use it to initialize synchronization and other variables.
 * 
 * parameters: the number of bowls
 */
void
catmouse_sync_init(int bowls)
{
  bowlockArry = kmalloc(sizeof(struct lock *) * bowls);
  bowlNum = bowls;
  status = 0;
  KASSERT (bowlockArry != NULL);
  struct lock *tmp;
  for(int i=0;i<bowls;i++){
	tmp = lock_create("lockNameNotMatter");
	KASSERT(tmp != NULL);
	bowlockArry[i] = tmp;
  }

  cat_turn_cv = cv_create("cvNameNotMatter");
  KASSERT(cat_turn_cv != NULL);
  mouse_turn_cv = cv_create("cvNameNotMatter");
  KASSERT(mouse_turn_cv != NULL);
  return;
}

/* 
 * The CatMouse simulation will call this function once after all cat
 * and mouse simulations are finished.
 *
 * You can use it to clean up any synchronization and other variables.
 *
 * parameters: the number of bowls
 */
void
catmouse_sync_cleanup(int bowls)
{
  struct lock *tmp;
  for(int i=0; i<bowls; i++){
	KASSERT(bowlockArry[i] != NULL);
	tmp = bowlockArry[i];
	lock_destroy(tmp);	
  }
  kfree(bowlockArry);

  KASSERT(cat_turn_cv != NULL);
  cv_destroy(cat_turn_cv);
  KASSERT(mouse_turn_cv != NULL);
  cv_destroy(mouse_turn_cv);
}


/*
 * The CatMouse simulation will call this function each time a cat wants
 * to eat, before it eats.
 * This function should cause the calling thread (a cat simulation thread)
 * to block until it is OK for a cat to eat at the specified bowl.
 *
 * parameter: the number of the bowl at which the cat is trying to eat
 *             legal bowl numbers are 1..NumBowls
 *
 * return value: none
 */

void
cat_before_eating(unsigned int bowl) 
{
  int bowlIndex = (int) bowl - 1;
  struct lock *bowlock;
  bowlock = bowlockArry[bowlIndex];
  KASSERT(bowlock != NULL);
  lock_acquire(bowlock);
  while( !is_cat_turn()){
	cv_wait(cat_turn_cv,bowlock);
  }
  status++;
}

/*
 * The CatMouse simulation will call this function each time a cat finishes
 * eating.
 *
 * You can use this function to wake up other creatures that may have been
 * waiting to eat until this cat finished.
 *
 * parameter: the number of the bowl at which the cat is finishing eating.
 *             legal bowl numbers are 1..NumBowls
 *
 * return value: none
 */

void
cat_after_eating(unsigned int bowl) 
{
  int bowlIndex = (int) bowl - 1;
  struct lock *bowlock;
  bowlock = bowlockArry[bowlIndex];
  KASSERT(bowlock != NULL);
  
  status--;
  if(is_mouse_turn()) cv_broadcast(mouse_turn_cv,bowlock);
  lock_release(bowlock);
}

/*
 * The CatMouse simulation will call this function each time a mouse wants
 * to eat, before it eats.
 * This function should cause the calling thread (a mouse simulation thread)
 * to block until it is OK for a mouse to eat at the specified bowl.
 *
 * parameter: the number of the bowl at which the mouse is trying to eat
 *             legal bowl numbers are 1..NumBowls
 *
 * return value: none
 */

void
mouse_before_eating(unsigned int bowl) 
{
  int bowlIndex = (int) bowl - 1;
  struct lock *bowlock;
  bowlock = bowlockArry[bowlIndex];
  KASSERT(bowlock != NULL);
  lock_acquire(bowlock);
  while( !is_mouse_turn()){
	cv_wait(mouse_turn_cv,bowlock);
  }
  status--;
}

/*
 * The CatMouse simulation will call this function each time a mouse finishes
 * eating.
 *
 * You can use this function to wake up other creatures that may have been
 * waiting to eat until this mouse finished.
 *
 * parameter: the number of the bowl at which the mouse is finishing eating.
 *             legal bowl numbers are 1..NumBowls
 *
 * return value: none
 */

void
mouse_after_eating(unsigned int bowl) 
{
  int bowlIndex = (int) bowl - 1;
  struct lock *bowlock;
  bowlock = bowlockArry[bowlIndex];
  KASSERT(bowlock != NULL);
  status++;

  if(is_cat_turn()) cv_broadcast(cat_turn_cv,bowlock);
  lock_release(bowlock);

}
