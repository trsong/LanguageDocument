/*
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2008, 2009
 *	The President and Fellows of Harvard College.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <spl.h>
#include <spinlock.h>
#include <proc.h>
#include <current.h>
#include <mips/tlb.h>
#include <addrspace.h>
#include <vm.h>
#include "opt-A3.h"

#if OPT_A3
#include <syscall.h>
#define VM_KASSERT(X)	KASSERT(X)

static volatile bool is_bitmap_init = false;
static paddr_t paddrlo;
static paddr_t paddrhi;
static unsigned long bitmap_size = 0;
static struct BME *bitmap = NULL;

static unsigned int mallocated = 0;
static unsigned int mfreed = 0;

#endif

#if OPT_A3
unsigned long kbitmap_entry(paddr_t);
paddr_t kbitmap_allockpage(unsigned long); // utility functions for getppages()
void kbitmap_freekpage(paddr_t);


struct BME{
	bool freed;
	unsigned long size;
};

struct PTE{
	vaddr_t vaddr;
	paddr_t paddr;
};


static int kbitmap_init_function();
static int kbitmap_init_function(){
	KASSERT(!is_bitmap_init);
	ram_getsize(&paddrlo,&paddrhi);
	bitmap_size = (paddrhi - paddrlo)/PAGE_SIZE;
	bitmap = kmalloc(bitmap_size * sizeof(struct BME));
	if(bitmap == NULL){
		DEBUG(DB_THREADS,"***************Unable to create bitmap*********** \n");
		return ENOMEM;
	}
	DEBUG(DB_THREADS,"------------------bitmap Init-------------\n bitmap_size = %d \n",(int)bitmap_size);
	for(unsigned long i=0; i < bitmap_size; i++){
		bitmap[i].freed = true;
		bitmap[i].size = 0;
	}	
	ram_getsize(&paddrlo,&paddrhi);
	is_bitmap_init = true;
	return 0;
}



#endif
/*
 * Dumb MIPS-only "VM system" that is intended to only be just barely
 * enough to struggle off the ground. You should replace all of this
 * code while doing the VM assignment. In fact, starting in that
 * assignment, this file is not included in your kernel!
 */

/* under dumbvm, always have 48k of user stack */
#define DUMBVM_STACKPAGES    12

/*
 * Wrap rma_stealmem in a spinlock.
 */
static struct spinlock stealmem_lock = SPINLOCK_INITIALIZER;

void
vm_bootstrap(void)
{
	/* Do nothing. */
#if OPT_A3
	kbitmap_init_function();
	is_bitmap_init = true;
#endif
}

static
paddr_t
getppages(unsigned long npages)
{
	paddr_t addr;

	spinlock_acquire(&stealmem_lock);
#if OPT_A3
	addr = is_bitmap_init? kbitmap_allockpage(npages):ram_stealmem(npages);
	//if(is_bitmap_init) DEBUG(DB_THREADS,"************getppages: GET %d pages from kbitmap_allockpage.\n" ,(int) npages);
#else
	addr = ram_stealmem(npages);
#endif
	spinlock_release(&stealmem_lock);
	return addr;
}

/* Allocate/free some kernel-space virtual pages */
vaddr_t 
alloc_kpages(int npages)
{
	paddr_t pa;
	pa = getppages(npages);
	if (pa==0) {
		return 0;
	}
	return PADDR_TO_KVADDR(pa);
}

void 
free_kpages(vaddr_t addr)
{

// notice addr is vaddr need to translate into kernel physical addr
	/* nothing - leak the memory. */
#if OPT_A3
	if (addr > MIPS_KSEG0) kbitmap_freekpage(addr-MIPS_KSEG0);
#endif
	(void)addr;
}

void
vm_tlbshootdown_all(void)
{
	panic("dumbvm tried to do tlb shootdown?!\n");
}

void
vm_tlbshootdown(const struct tlbshootdown *ts)
{
	(void)ts;
	panic("dumbvm tried to do tlb shootdown?!\n");
}

int
vm_fault(int faulttype, vaddr_t faultaddress)
{
	vaddr_t vbase1, vtop1, vbase2, vtop2, stackbase, stacktop;
	paddr_t paddr;
	int i;
	uint32_t ehi, elo;
	struct addrspace *as;
	int spl;

	faultaddress &= PAGE_FRAME;

	DEBUG(DB_VM, "dumbvm: fault: 0x%x\n", faultaddress);

	switch (faulttype) {
	    case VM_FAULT_READONLY:
#if OPT_A3
		sys__exit(1);
#else
		/* We always create pages read-write, so we can't get this */
		panic("dumbvm: got VM_FAULT_READONLY\n");
#endif
	    case VM_FAULT_READ:
	    case VM_FAULT_WRITE:
		break;
	    default:
		return EINVAL;
	}

	if (curproc == NULL) {
		/*
		 * No process. This is probably a kernel fault early
		 * in boot. Return EFAULT so as to panic instead of
		 * getting into an infinite faulting loop.
		 */
		return EFAULT;
	}

	as = curproc_getas();
	if (as == NULL) {
		/*
		 * No address space set up. This is probably also a
		 * kernel fault early in boot.
		 */
		return EFAULT;
	}

	/* Assert that the address space has been set up properly. */
	KASSERT(as->as_vbase1 != 0);
	KASSERT(as->as_pbase1 != 0);
	KASSERT(as->as_npages1 != 0);
	KASSERT(as->as_vbase2 != 0);
	KASSERT(as->as_pbase2 != 0);
	KASSERT(as->as_npages2 != 0);
	KASSERT(as->as_stackpbase != 0);
	KASSERT((as->as_vbase1 & PAGE_FRAME) == as->as_vbase1);
	KASSERT((as->as_pbase1 & PAGE_FRAME) == as->as_pbase1);
	KASSERT((as->as_vbase2 & PAGE_FRAME) == as->as_vbase2);
	KASSERT((as->as_pbase2 & PAGE_FRAME) == as->as_pbase2);
	KASSERT((as->as_stackpbase & PAGE_FRAME) == as->as_stackpbase);

	vbase1 = as->as_vbase1;
	vtop1 = vbase1 + as->as_npages1 * PAGE_SIZE;
	vbase2 = as->as_vbase2;
	vtop2 = vbase2 + as->as_npages2 * PAGE_SIZE;
	stackbase = USERSTACK - DUMBVM_STACKPAGES * PAGE_SIZE;
	stacktop = USERSTACK;

#if OPT_A3
	bool is_code_seg = false;
	bool is_data_seg = false;
	bool is_stack_seg = false;
	bool find_page = false;
	if (faultaddress >= vbase1 && faultaddress < vtop1) is_code_seg = true;
	else if (faultaddress >= vbase2 && faultaddress < vtop2) is_data_seg = true;
	else if (faultaddress >= stackbase && faultaddress < stacktop) is_stack_seg = true;
	else return EFAULT;

	if(is_code_seg){
		int index = (faultaddress - vbase1) / PAGE_SIZE;
		if( as->codeMap[index].vaddr == faultaddress){
				paddr = as->codeMap[index].paddr;
				find_page  = true;
		}else{
		for(unsigned int i=0; i < as->as_npages1; i++){
			if(as->codeMap[i].vaddr == faultaddress){
				paddr = as->codeMap[i].paddr;
				find_page  = true;
			}
		}
		}


	}else if(is_data_seg){
		int index = (faultaddress - vbase2) / PAGE_SIZE;
		if( as->dataMap[index].vaddr == faultaddress){
				paddr = as->dataMap[index].paddr;
				find_page  = true;
		}else{
		for(unsigned int i=0; i < as->as_npages2; i++){
			if(as->dataMap[i].vaddr == faultaddress){
				paddr = as->dataMap[i].paddr;
				find_page  = true;
			}
		}
		}

	}else if(is_stack_seg){
		for(unsigned int i=0; i < DUMBVM_STACKPAGES; i++){
			if(as->stackMap[i].vaddr == faultaddress){
				paddr = as->stackMap[i].paddr;
				find_page  = true;
			}
		}

	}
	
	VM_KASSERT(find_page == true);
	//DEBUG(DB_THREADS," (%x) => [%x]\n", (int)faultaddress, (int)paddr);

#else
	if (faultaddress >= vbase1 && faultaddress < vtop1) {
		paddr = (faultaddress - vbase1) + as->as_pbase1;

	}
	else if (faultaddress >= vbase2 && faultaddress < vtop2) {
		paddr = (faultaddress - vbase2) + as->as_pbase2;
	}
	else if (faultaddress >= stackbase && faultaddress < stacktop) {
		paddr = (faultaddress - stackbase) + as->as_stackpbase;
	}
	else {
		return EFAULT;
	}

#endif

	/* make sure it's page-aligned */
	KASSERT((paddr & PAGE_FRAME) == paddr);

	/* Disable interrupts on this CPU while frobbing the TLB. */
	spl = splhigh();

	for (i=0; i<NUM_TLB; i++) {
		tlb_read(&ehi, &elo, i);
		if (elo & TLBLO_VALID) {
			continue;
		}
		ehi = faultaddress;
#if OPT_A3
		if(as->code_loaded && is_code_seg) elo = paddr | TLBLO_VALID;
		else elo = paddr | TLBLO_DIRTY | TLBLO_VALID;
#else
		elo = paddr | TLBLO_DIRTY | TLBLO_VALID;
#endif
		DEBUG(DB_VM, "dumbvm: 0x%x -> 0x%x\n", faultaddress, paddr);
		tlb_write(ehi, elo, i);
		splx(spl);
		return 0;
	}
	
#if OPT_A3
	ehi = faultaddress;
	if(as->code_loaded && is_code_seg) elo = paddr | TLBLO_VALID;
	else elo = paddr | TLBLO_DIRTY | TLBLO_VALID;

	DEBUG(DB_VM, "dumbvm: 0x%x -> 0x%x\n", faultaddress, paddr);
	tlb_random(ehi, elo);
	splx(spl);
	return 0;
#else
	kprintf("dumbvm: Ran out of TLB entries - cannot handle page fault\n");


	splx(spl);
	return EFAULT;
#endif
}

struct addrspace *
as_create(void)
{
	struct addrspace *as = kmalloc(sizeof(struct addrspace));
	if (as==NULL) {
		return NULL;
	}

	as->as_vbase1 = 0;
	as->as_pbase1 = 0;
	as->as_npages1 = 0;
	as->as_vbase2 = 0;
	as->as_pbase2 = 0;
	as->as_npages2 = 0;
	as->as_stackpbase = 0;
#if OPT_A3
	as->code_loaded = false;
	as->codeMap = NULL;
	as->dataMap = NULL;
	as->stackMap = NULL;
#endif
	return as;
}

void
as_destroy(struct addrspace *as)
{
#if OPT_A3
	for(unsigned int i=0; i<as->as_npages1; i++){
		kbitmap_freekpage((as->codeMap)[i].paddr);
	}
	for(unsigned int i=0; i<as->as_npages2; i++){
		kbitmap_freekpage((as->dataMap)[i].paddr);
	}
	for(unsigned int i=0; i<DUMBVM_STACKPAGES; i++){
		kbitmap_freekpage((as->stackMap)[i].paddr);
	}
	
	kfree(as->codeMap);
	kfree(as->dataMap);
	kfree(as->stackMap);
	//kfree(as);
	DEBUG(DB_THREADS, "@@@@@@@@@@@@@@@@@@@@@ Memory Summary @@@@@@@@@@@@@@@\n");
	DEBUG(DB_THREADS, "mallocated:%d, mfreed:%d \n", (int)mallocated, (int)mfreed);
	for(unsigned long i =0; i < bitmap_size; i++){	
	    DEBUG(DB_THREADS,"%c",(bitmap[i].freed)? '_':'*');
	}
#endif
	kfree(as);
}

void
as_activate(void)
{
	int i, spl;
	struct addrspace *as;

	as = curproc_getas();
#ifdef UW
        /* Kernel threads don't have an address spaces to activate */
#endif
	if (as == NULL) {
		return;
	}

	/* Disable interrupts on this CPU while frobbing the TLB. */
	spl = splhigh();

	for (i=0; i<NUM_TLB; i++) {
		tlb_write(TLBHI_INVALID(i), TLBLO_INVALID(), i);
	}

	splx(spl);
}

void
as_deactivate(void)
{
	/* nothing */
}

int
as_define_region(struct addrspace *as, vaddr_t vaddr, size_t sz,
		 int readable, int writeable, int executable)
{
	size_t npages; 

	/* Align the region. First, the base... */
	sz += vaddr & ~(vaddr_t)PAGE_FRAME;
	vaddr &= PAGE_FRAME;

	/* ...and now the length. */
	sz = (sz + PAGE_SIZE - 1) & PAGE_FRAME;

	npages = sz / PAGE_SIZE;

	/* We don't use these - all pages are read-write */
	(void)readable;
	(void)writeable;
	(void)executable;

	if (as->as_vbase1 == 0) {
		as->as_vbase1 = vaddr;
		as->as_npages1 = npages;
		return 0;
	}

	if (as->as_vbase2 == 0) {
		as->as_vbase2 = vaddr;
		as->as_npages2 = npages;
		return 0;
	}

	/*
	 * Support for more than two regions is not available.
	 */
	kprintf("dumbvm: Warning: too many regions\n");
	return EUNIMP;
}

static
void
as_zero_region(paddr_t paddr, unsigned npages)
{
	bzero((void *)PADDR_TO_KVADDR(paddr), npages * PAGE_SIZE);
}

int
as_prepare_load(struct addrspace *as)
{
	KASSERT(as->as_pbase1 == 0);
	KASSERT(as->as_pbase2 == 0);
	KASSERT(as->as_stackpbase == 0);
#if OPT_A3
	bool pbase_set = false;
	//allocat physical page and page table entry for Code segment
	as->codeMap = kmalloc(as->as_npages1 * sizeof(struct PTE));
	if(as->codeMap == NULL) return ENOMEM;
	as->dataMap = kmalloc(as->as_npages2 * sizeof(struct PTE));
	if(as->dataMap == NULL) return ENOMEM;
	as->stackMap = kmalloc(DUMBVM_STACKPAGES * sizeof(struct PTE));
	if(as->stackMap == NULL) return ENOMEM;
	DEBUG(DB_THREADS,"====================as_prepare_load===============\n");
	DEBUG(DB_THREADS,"code_size: %d \n data_size:%d \n stack_size:%d \n",(int)as->as_npages1,(int)as->as_npages2,(int)DUMBVM_STACKPAGES);
	for(unsigned int i=0; i< as->as_npages1; i++){
		struct PTE *pte = & as->codeMap[i];
		pte->paddr = getppages(1);			//might return NULL				
		if(pte->paddr == 0) return ENOMEM;
		as_zero_region(pte->paddr,1);
		pte->vaddr = as->as_vbase1 + PAGE_SIZE * i;
		if(i==0){
			as->as_pbase1= pte->paddr;
			pbase_set = true;
		}
	}
	DEBUG(DB_THREADS,"+code_seg: vaddr(%x), paddr(%x)\n",(int)as->as_vbase1,(int)as->as_pbase1);
	KASSERT(as->as_pbase1 != 0);
	KASSERT(pbase_set);

	pbase_set = false;
	// for data segment
	for(unsigned int i=0; i< as->as_npages2; i++){
		struct PTE *pte = & as->dataMap[i];
		pte->paddr = getppages(1);			//might return NULL				
		if(pte->paddr == 0) return ENOMEM;
		as_zero_region(pte->paddr,1);
		pte->vaddr = as->as_vbase2 + PAGE_SIZE * i;
		if(i==0){
			as->as_pbase2= pte->paddr;
			pbase_set = true;
		}
	}
	KASSERT(as->as_pbase2 != 0);
	KASSERT(pbase_set);
	DEBUG(DB_THREADS,"+data_seg: vaddr(%x), paddr(%x)\n",(int)as->as_vbase2,(int)as->as_pbase2);

	//for stack
	pbase_set = false;
	for(unsigned int i=0; i <DUMBVM_STACKPAGES ; i++){
		struct PTE *pte = & as->stackMap[i];
		pte->paddr = getppages(1);			//might return NULL				
		if(pte->paddr == 0) return ENOMEM;
		as_zero_region(pte->paddr,1);
		pte->vaddr = USERSTACK - PAGE_SIZE * i;
		if(i ==0 ){
			as->as_stackpbase = pte->paddr;
			pbase_set = true;
		}
	}
	KASSERT(as->as_stackpbase != 0);
	KASSERT(pbase_set);
	DEBUG(DB_THREADS,"+stack_seg: vaddr(%x), paddr(%x)\n",(int)USERSTACK,(int)as->as_stackpbase);

	DEBUG(DB_THREADS,"=+=+=+=+=+=+=+=+=+=+as_prepare_load=+=+=+=+=+=+=+=+=+=+=+=+\n");
#else
	as->as_pbase1 = getppages(as->as_npages1);
	if (as->as_pbase1 == 0) {
		return ENOMEM;
	}

	as->as_pbase2 = getppages(as->as_npages2);
	if (as->as_pbase2 == 0) {
		return ENOMEM;
	}

	as->as_stackpbase = getppages(DUMBVM_STACKPAGES);
	if (as->as_stackpbase == 0) {
		return ENOMEM;
	}
	
	as_zero_region(as->as_pbase1, as->as_npages1);
	as_zero_region(as->as_pbase2, as->as_npages2);
	as_zero_region(as->as_stackpbase, DUMBVM_STACKPAGES);
#endif

	return 0;
}

int
as_complete_load(struct addrspace *as)
{
	(void)as;
	return 0;
}

int
as_define_stack(struct addrspace *as, vaddr_t *stackptr)
{
	KASSERT(as->as_stackpbase != 0);
	*stackptr = USERSTACK;
	return 0;
}

int
as_copy(struct addrspace *old, struct addrspace **ret)
{
	struct addrspace *new;

	new = as_create();
	if (new==NULL) {
		return ENOMEM;
	}

	new->as_vbase1 = old->as_vbase1;
	new->as_npages1 = old->as_npages1;
	new->as_vbase2 = old->as_vbase2;
	new->as_npages2 = old->as_npages2;

	/* (Mis)use as_prepare_load to allocate some physical memory. */
	if (as_prepare_load(new)) {
		as_destroy(new);
		return ENOMEM;
	}

	KASSERT(new->as_pbase1 != 0);
	KASSERT(new->as_pbase2 != 0);
	KASSERT(new->as_stackpbase != 0);

#if OPT_A3
	for(unsigned int i=0; i< old->as_npages1; i++){
		memmove((void *)PADDR_TO_KVADDR(new->codeMap[i].paddr),
		(const void *)PADDR_TO_KVADDR(old->codeMap[i].paddr),
		PAGE_SIZE);
	}

	for(unsigned int i=0; i< old->as_npages2; i++){
		memmove((void *)PADDR_TO_KVADDR(new->dataMap[i].paddr),
		(const void *)PADDR_TO_KVADDR(old->dataMap[i].paddr),
		PAGE_SIZE);
	}

	for(unsigned int i=0; i< DUMBVM_STACKPAGES; i++){
		memmove((void *)PADDR_TO_KVADDR(new->stackMap[i].paddr),
		(const void *)PADDR_TO_KVADDR(old->stackMap[i].paddr),
		PAGE_SIZE);
	}
#else
	memmove((void *)PADDR_TO_KVADDR(new->as_pbase1),
		(const void *)PADDR_TO_KVADDR(old->as_pbase1),
		old->as_npages1*PAGE_SIZE);

	memmove((void *)PADDR_TO_KVADDR(new->as_pbase2),
		(const void *)PADDR_TO_KVADDR(old->as_pbase2),
		old->as_npages2*PAGE_SIZE);

	memmove((void *)PADDR_TO_KVADDR(new->as_stackpbase),
		(const void *)PADDR_TO_KVADDR(old->as_stackpbase),
		DUMBVM_STACKPAGES*PAGE_SIZE);
#endif
	*ret = new;
	return 0;
}


#if OPT_A3
unsigned long
kbitmap_entry(paddr_t paddr){
	if(!is_bitmap_init) return 0;
	return (paddr-paddrlo)/PAGE_SIZE;
}

paddr_t kbitmap_allockpage(unsigned long npages){
	mallocated += npages;
	size_t size = npages * PAGE_SIZE;
	if (paddrlo + size > paddrhi) {
		//panic("No MEM!\n");
		return 0;
	}
	for(unsigned long i=0; i<bitmap_size; i++){
		if(!bitmap[i].freed) continue;
		bool jmpNext = false;
		for(unsigned long j=0; j<npages; j++){
			if(i+j >= bitmap_size) return 0;
			if(!bitmap[i+j].freed){
				jmpNext = true;
				i += j;
				DEBUG(DB_THREADS,"^^^^^^^________^^^^^^ memory segmentation at %d \n",(int)(i+j));
				break;
			}
		}
		
		if(jmpNext) continue;

		bitmap[i].size = npages;
		for(unsigned long j=0; j<npages; j++){
			bitmap[i+j].freed = false;
		}
		//DEBUG(DB_THREADS,"---------------kbitmap_allockpage: allocate %d pages, at slot %d \n",(int)npages,(int)i);
		return i*PAGE_SIZE + paddrlo;
		
	}
	//panic("No continuous MEM!\n");
	return 0;
	
}

void kbitmap_freekpage(paddr_t paddr){
	if (paddr < paddrlo) return;
	unsigned int index = kbitmap_entry(paddr);
	if(bitmap[index].freed)
		DEBUG(DB_THREADS,"************ Warning, try to double free in bitmap_freekpage. paddr = %x ************\n",paddr);
	DEBUG(DB_THREADS,"#################### kbitmap_freekpage: free %d pages, at slot %d.\n",(int)bitmap[index].size,index);
	mfreed += bitmap[index].size;
	for(unsigned int i = 0; i < bitmap[index].size ; i++){
		bitmap[i+index].freed = true;
	}
	bitmap[index].size = 0;
}

#endif
